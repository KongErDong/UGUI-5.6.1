using UnityEngine.UI;

namespace UnityEditor.UI
{
    /*
[CustomEditor(typeof(Mask), true)]
[CanEditMultipleObjects]
public class MaskEditor : ImageEditor
{
    SerializedProperty m_DrawImage;

    protected override void OnEnable ()
    {
        base.OnEnable();
        m_DrawImage = serializedObject.FindProperty("m_DrawImage");
    }

    public override void OnInspectorGUI ()
    {
        base.OnInspectorGUI ();

        serializedObject.Update();
        EditorGUILayout.PropertyField (m_DrawImage);
        serializedObject.ApplyModifiedProperties();
    }
}*/
}

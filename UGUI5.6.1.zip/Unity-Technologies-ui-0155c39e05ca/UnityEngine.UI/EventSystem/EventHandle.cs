using System;

namespace UnityEngine.EventSystems
{
    [Flags]
    public enum EventHandle
    {
        Unused = 0,
        Used = 1
    }
}

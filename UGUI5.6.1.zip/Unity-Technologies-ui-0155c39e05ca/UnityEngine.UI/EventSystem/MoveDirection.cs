namespace UnityEngine.EventSystems
{
    public enum MoveDirection
    {
        Left,
        Up,
        Right,
        Down,
        None
    }
}

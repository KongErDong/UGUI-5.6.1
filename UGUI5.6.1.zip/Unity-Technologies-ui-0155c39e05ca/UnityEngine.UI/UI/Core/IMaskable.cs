using System;

namespace UnityEngine.UI
{
    public interface IMaskable
    {
        void RecalculateMasking();
    }
}
